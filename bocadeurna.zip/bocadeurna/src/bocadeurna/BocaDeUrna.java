package bocadeurna;

import javax.swing.UIManager;

public class BocaDeUrna {
    public static void main(String[] args) {
        try {
            // Usar un look and feel moderno
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception e) {
            e.printStackTrace();
        }
        // Inicializar el menú principal
        MenuPrincipal menu = new MenuPrincipal();
        menu.setLocationRelativeTo(null);  // Centrar la ventana
        menu.setVisible(true);
    }
}

