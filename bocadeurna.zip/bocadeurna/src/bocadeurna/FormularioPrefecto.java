package bocadeurna;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FormularioPrefecto extends JFrame {
    private JTextField nombreField;
    private JTextField provinciaField;
    private JButton guardarButton;
    
    public FormularioPrefecto() {
        setTitle("Formulario de Prefectos");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel nombreLabel = new JLabel("Nombre:");
        nombreField = new JTextField(15);
        JLabel provinciaLabel = new JLabel("Provincia:");
        provinciaField = new JTextField(15);
        guardarButton = new JButton("Guardar");
        
        guardarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String nombre = nombreField.getText();
                String provincia = provinciaField.getText();
                
                if (!nombre.isEmpty() && !provincia.isEmpty()) {
                    Prefecto prefecto = new Prefecto(nombre, provincia);
                    Prefecto.agregarPrefecto(prefecto);
                    JOptionPane.showMessageDialog(null, "Prefecto guardado exitosamente");
                    nombreField.setText("");
                    provinciaField.setText("");
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, complete todos los campos");
                }
            }
        });
        
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(nombreLabel, gbc);
        gbc.gridx = 1;
        add(nombreField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 1;
        add(provinciaLabel, gbc);
        gbc.gridx = 1;
        add(provinciaField, gbc);
        gbc.gridx = 1;
        gbc.gridy = 2;
        add(guardarButton, gbc);
    }
}



