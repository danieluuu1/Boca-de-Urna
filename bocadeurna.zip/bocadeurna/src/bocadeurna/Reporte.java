package bocadeurna;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Reporte extends JFrame {
    private String tipo;

    public Reporte(String tipo) {
        this.tipo = tipo;
        setTitle("Reporte de Resultados");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        
        JTextArea reporteArea = new JTextArea();
        reporteArea.setEditable(false);
        
        if (tipo.equals("provincia")) {
            generarReportePorProvincia(reporteArea);
        } else if (tipo.equals("canton")) {
            generarReportePorCanton(reporteArea);
        }
        
        add(new JScrollPane(reporteArea), BorderLayout.CENTER);
    }

    private void generarReportePorProvincia(JTextArea reporteArea) {
        Map<String, Integer> resultados = new HashMap<>();
        
        for (Voto voto : Voto.getVotos()) {
            String provincia = voto.getPrefecto().getProvincia();
            resultados.put(provincia, resultados.getOrDefault(provincia, 0) + voto.getNumeroVotos());
        }
        
        StringBuilder reporte = new StringBuilder();
        reporte.append("Resultados por Provincia:\n\n");
        for (Map.Entry<String, Integer> entry : resultados.entrySet()) {
            reporte.append("Provincia: ").append(entry.getKey())
                    .append(" - Votos: ").append(entry.getValue()).append("\n");
        }
        
        reporteArea.setText(reporte.toString());
    }

    private void generarReportePorCanton(JTextArea reporteArea) {
        Map<String, Integer> resultados = new HashMap<>();
        
        for (Voto voto : Voto.getVotos()) {
            String canton = voto.getPrefecto().getNombre();
            resultados.put(canton, resultados.getOrDefault(canton, 0) + voto.getNumeroVotos());
        }
        
        StringBuilder reporte = new StringBuilder();
        reporte.append("Resultados por Cantón o Ciudad:\n\n");
        for (Map.Entry<String, Integer> entry : resultados.entrySet()) {
            reporte.append("Cantón o Ciudad: ").append(entry.getKey())
                    .append(" - Votos: ").append(entry.getValue()).append("\n");
        }
        
        reporteArea.setText(reporte.toString());
    }
}





