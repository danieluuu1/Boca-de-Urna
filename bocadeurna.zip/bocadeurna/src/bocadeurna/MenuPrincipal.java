package bocadeurna;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuPrincipal extends JFrame {
    public MenuPrincipal() {
        setTitle("Sistema de Boca de Urna");
        setSize(600, 400);  // Aumentar el tamaño de la ventana
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        JMenuBar menuBar = new JMenuBar();
        
        // Menú Archivo
        JMenu menuArchivo = new JMenu("Archivo");
        JMenuItem menuSalir = new JMenuItem("Salir");
        menuSalir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        menuArchivo.add(menuSalir);
        menuBar.add(menuArchivo);
        
        // Menú Candidatos
        JMenu menuCandidatos = new JMenu("Candidatos");
        JMenuItem menuPrefectos = new JMenuItem("Prefectos");
        menuPrefectos.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                FormularioPrefecto formulario = new FormularioPrefecto();
                formulario.setLocationRelativeTo(null);  // Centrar la ventana
                formulario.setVisible(true);
            }
        });
        menuCandidatos.add(menuPrefectos);
        menuBar.add(menuCandidatos);
        
        // Menú Proceso
        JMenu menuProceso = new JMenu("Proceso");
        JMenuItem menuBocaDeUrna = new JMenuItem("Boca de urna");
        menuBocaDeUrna.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                FormularioVoto formulario = new FormularioVoto();
                formulario.setLocationRelativeTo(null);  // Centrar la ventana
                formulario.setVisible(true);
            }
        });
        menuProceso.add(menuBocaDeUrna);
        menuBar.add(menuProceso);
        
        // Menú Reportes
        JMenu menuReportes = new JMenu("Reportes");
        JMenuItem menuResultadosProvincia = new JMenuItem("Resultados por provincia");
        JMenuItem menuResultadosCanton = new JMenuItem("Resultados por cantón o ciudad");
        
        menuResultadosProvincia.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Reporte reporte = new Reporte("provincia");
                reporte.setLocationRelativeTo(null);  // Centrar la ventana
                reporte.setVisible(true);
            }
        });
        
        menuResultadosCanton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Reporte reporte = new Reporte("canton");
                reporte.setLocationRelativeTo(null);  // Centrar la ventana
                reporte.setVisible(true);
            }
        });
        
        menuReportes.add(menuResultadosProvincia);
        menuReportes.add(menuResultadosCanton);
        menuBar.add(menuReportes);
        
        setJMenuBar(menuBar);
    }
}



