package bocadeurna;

import java.util.ArrayList;
import java.util.List;

public class Voto {
    private static List<Voto> votos = new ArrayList<>();
    private Prefecto prefecto;
    private int numeroVotos;

    public Voto(Prefecto prefecto, int numeroVotos) {
        this.prefecto = prefecto;
        this.numeroVotos = numeroVotos;
    }

    public static void agregarVoto(Voto voto) {
        votos.add(voto);
    }

    public static List<Voto> getVotos() {
        return new ArrayList<>(votos);  // Devuelve una copia para evitar modificaciones externas
    }

    public Prefecto getPrefecto() {
        return prefecto;
    }

    public int getNumeroVotos() {
        return numeroVotos;
    }
}




