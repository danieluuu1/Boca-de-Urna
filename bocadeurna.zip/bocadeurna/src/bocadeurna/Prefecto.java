package bocadeurna;

import java.util.ArrayList;
import java.util.List;

public class Prefecto {
    private static List<Prefecto> prefectos = new ArrayList<>();
    private String nombre;
    private String provincia;

    public Prefecto(String nombre, String provincia) {
        this.nombre = nombre;
        this.provincia = provincia;
    }

    public static void agregarPrefecto(Prefecto prefecto) {
        prefectos.add(prefecto);
    }

    public static List<Prefecto> getPrefectos() {
        return new ArrayList<>(prefectos);  // Devuelve una copia para evitar modificaciones externas
    }

    public String getNombre() {
        return nombre;
    }

    public String getProvincia() {
        return provincia;
    }

    @Override
    public String toString() {
        return nombre + " (" + provincia + ")";
    }
}


