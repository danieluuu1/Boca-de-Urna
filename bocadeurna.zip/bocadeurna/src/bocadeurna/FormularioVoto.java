package bocadeurna;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FormularioVoto extends JFrame {
    private JComboBox<Prefecto> prefectoComboBox;
    private JTextField votosField;
    private JButton asignarButton;
    
    public FormularioVoto() {
        setTitle("Formulario de Boca de Urna");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel prefectoLabel = new JLabel("Prefecto:");
        prefectoComboBox = new JComboBox<>(Prefecto.getPrefectos().toArray(new Prefecto[0]));
        JLabel votosLabel = new JLabel("Número de votos:");
        votosField = new JTextField(15);
        asignarButton = new JButton("Asignar");
        
        asignarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Prefecto prefecto = (Prefecto) prefectoComboBox.getSelectedItem();
                int votos;
                
                try {
                    votos = Integer.parseInt(votosField.getText());
                    if (votos <= 0) {
                        throw new NumberFormatException();
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Por favor, ingrese un número de votos válido");
                    return;
                }
                
                if (prefecto != null && votos > 0) {
                    Voto voto = new Voto(prefecto, votos);
                    Voto.agregarVoto(voto);
                    JOptionPane.showMessageDialog(null, "Votos asignados exitosamente");
                    votosField.setText("");
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, seleccione un prefecto y asigne un número de votos válido");
                }
            }
        });
        
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(prefectoLabel, gbc);
        gbc.gridx = 1;
        add(prefectoComboBox, gbc);
        gbc.gridx = 0;
        gbc.gridy = 1;
        add(votosLabel, gbc);
        gbc.gridx = 1;
        add(votosField, gbc);
        gbc.gridx = 1;
        gbc.gridy = 2;
        add(asignarButton, gbc);
    }
}



